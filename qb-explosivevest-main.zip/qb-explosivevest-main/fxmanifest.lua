fx_version 'adamant'
game 'gta5'


description 'qb-suicidevest'
version '1.0'
author 'https://github.com/OmegaGrape'


client_scripts {
    'client/main.lua'
}

shared_script 'config.lua'
