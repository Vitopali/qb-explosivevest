source of the vest https://www.gta5-mods.com/player/explosive-vest-eup
